# MKLRGCN
requirements:
  * Python 3.9 or higher
  * PyTorch 2.0.0 
  * torch-geometric 2.3.0
  * numpy 1.26.4
  * scikit-learn 1.1.3
# quick rum:
Execute python main.py to run the code
    
